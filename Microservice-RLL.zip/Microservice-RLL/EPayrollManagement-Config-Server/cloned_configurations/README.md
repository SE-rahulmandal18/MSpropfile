# mstest
These are the properties file that classifies two different databases
